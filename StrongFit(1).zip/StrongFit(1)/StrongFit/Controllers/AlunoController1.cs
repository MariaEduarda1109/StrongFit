﻿using Microsoft.AspNetCore.Mvc;
using StrongFit.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace StrongFit.Controllers
{
    public class AlunoController1 : Controller
    {
        public Context context;
        public AlunoController1(Context ctx)
        {
            context = ctx;
        }
        public IActionResult Index()
        {
            //return View(context.Alunos);
            return View(context.Alunos.Include(f => f.Personal));
        }
        public IActionResult Create()
        {
            ViewBag.PersonalId = new SelectList(context.Personais.OrderBy(f => f.Nome), "PersonalId", "Nome");
            return View();
        }
        [HttpPost]
        
        public IActionResult Create(Aluno aluno)
        {
            context.Add(aluno);
            context.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult Details(int id)
        {
            var aluno = context.Alunos.Include(a => a.Personal).FirstOrDefault(p => p.AlunoId == id);
            return View(aluno);
        }

        public IActionResult Edit(int id)
        {
            var aluno = context.Alunos.Find(id);
            ViewBag.PersonalId = new SelectList(context.Personais.OrderBy(f => f.Nome), "PersonalId", "Nome");
            return View(aluno);
        }
        [HttpPost]
        
        public IActionResult Edit(Aluno aluno)
        {
            context.Entry(aluno).State = EntityState.Modified;
            context.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult Delete(int id)
        {
            var produto = context.Alunos.Include(p => p.Personal).FirstOrDefault(a => a.AlunoId == id);
            return View(produto);
        }

        [HttpPost]
        public IActionResult Delete(Aluno aluno)
        {
            context.Alunos.Remove(aluno);
            context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
