﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using StrongFit.Models;
using System;

namespace StrongFit.Controllers
{
    public class PersonalController1 : Controller
    {
        public Context context;

        public PersonalController1(Context ctx)
        {
            context = ctx;
        }
        public IActionResult Index()
        {
            return View(context.Personais);
        }

        public IActionResult Create()
        {
            //ViewBag.PersonalId = new SelectList(context.Personais.OrderBy(p => p.Nome), "PersonalId", "Nome", "Especialidade");
            return View();
        }
        [HttpPost]
        //[ValidateAntiForgeryToken]
        public IActionResult Create(Personal personal)
        {
            context.Add(personal);
            context.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult Details(int id)
        {
            var personal = context.Personais.FirstOrDefault(p => p.PersonalId == id);
            return View(personal);
        }

        public IActionResult Edit(int id) 
        {
            var personal = context.Personais.Find(id);
            //ViewBag.PersonalId = new SelectList(context.Personais.OrderBy(p => p.Nome), "PersonalId", "Nome", "Especialidade");
            return View(personal);
        }
        [HttpPost]
        //[ValidateAntiForgeryToken]
        public IActionResult Edit(Personal personal)
        {
            context.Entry(personal).State = EntityState.Modified;
            context.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult Delete(int id)
        {
            var personal = context.Personais.FirstOrDefault(p => p.PersonalId == id);
            return View(personal);
        }
        [HttpPost]
        //[ValidateAntiForgeryToken]
        public IActionResult Delete(Personal personal)
        {
            context.Remove(personal);
            context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
