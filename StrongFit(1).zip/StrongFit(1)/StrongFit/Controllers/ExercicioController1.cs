﻿using Microsoft.AspNetCore.Mvc;
using StrongFit.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.Rendering;


namespace StrongFit.Controllers
{
    public class ExercicioController1 : Controller
    {
        public Context context;
        public ExercicioController1(Context ctx)
        {
            context = ctx;
        }
        public IActionResult Index()
        {
            return View(context.Exercicios);
        }

        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Exercicio exercicio)
        {
            context.Add(exercicio);
            context.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult Details(int id)
        {
            var exercicio = context.Exercicios.FirstOrDefault(e => e.ExercicioId == id);
            return View(exercicio);
        }

        public IActionResult Edit(int id)
        {
            var exercicios = context.Exercicios.Find(id);
            return View(exercicios);
        }
        [HttpPost]
        public IActionResult Edit(Exercicio exercicio)
        {
            context.Entry(exercicio).State = EntityState.Modified;
            context.SaveChanges();
            return RedirectToAction("Index");
        }
        public IActionResult Delete(int id)
        {
            var exercicio = context.Exercicios.FirstOrDefault(p => p.ExercicioId == id);
            return View(exercicio);
        }
        [HttpPost]
        public IActionResult Delete(Exercicio exercicio)
        {
            context.Remove(exercicio);
            context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
