﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using StrongFit.Models;
using System.Linq;

namespace StrongFit.Controllers
{
    public class TreinoController1 : Controller
    {
        public Context context;
        public TreinoController1(Context context)
        {
            this.context = context;
        }
        public IActionResult Index()
        {
            return View(context.Treinos.Include(t => t.Aluno).Include(t => t.Personal));
        }

        public IActionResult Create()
        {
            ViewBag.PersonalId = new SelectList(context.Personais.OrderBy(f => f.Nome), "PersonalId", "Nome");
            ViewBag.AlunoId = new SelectList(context.Alunos.OrderBy(f => f.Nome), "AlunoId", "Nome");
            return View();
        }
        [HttpPost]
        public IActionResult Create(Treino treino)
        {
            context.Add(treino);
            context.SaveChanges();
            return RedirectToAction("Index");
        }
        public IActionResult Details(int id)
        {
            var treino = context.Treinos.Include(t => t.Aluno).Include(t => t.Personal).FirstOrDefault(p => p.TreinoId == id);
            return View(treino);
        }

        public IActionResult Edit(int id)
        {
            var treino = context.Treinos.Find(id);
            ViewBag.PersonalId = new SelectList(context.Personais.OrderBy(f => f.Nome), "PersonalId", "Nome");
            ViewBag.AlunoId = new SelectList(context.Alunos.OrderBy(f => f.Nome), "AlunoId", "Nome");
            return View(treino);
        }
        [HttpPost]
        public IActionResult Edit(Treino treino)
        {
            context.Entry(treino).State = EntityState.Modified;
            context.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult Delete(int id)
        {
            var treino = context.Treinos.Include(t => t.Personal).Include(t => t.Aluno).FirstOrDefault(t => t.TreinoId == id);
            return View(treino);
        }
        [HttpPost]
        public IActionResult Delete(Treino treino)
        {
            context.Treinos.Remove(treino);
            context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
