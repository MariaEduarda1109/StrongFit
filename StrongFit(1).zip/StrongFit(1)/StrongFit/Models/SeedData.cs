﻿using Microsoft.EntityFrameworkCore;


namespace StrongFit.Models
{
    public class SeedData
    {
        public static void EnsurePopulated(IApplicationBuilder app)
        {
            Context context = app.ApplicationServices.GetRequiredService<Context>();
            context.Database.Migrate();
            

            if (!context.Alunos.Any())
            {
                context.Alunos.AddRange(
                    new Aluno { Nome = "Alice Ávila", Data_Nasc = DateTime.Parse("22-12-2000"), Email = "alicegmail.com", Instagram = "Alice_Avila", Telefone = "35999999999", Observacoes = "dor nas costas", PersonalId = 1 },
                    new Aluno { Nome = "Gabriel Lapa", Data_Nasc = DateTime.Parse("22-12-2002"), Email = "gb@gmail.com", Instagram = "Gabriel_lapa", Telefone = "35888888888", Observacoes = "Sopro", PersonalId = 2 },
                    new Aluno { Nome = "Maria Eduarda Monteiro", Data_Nasc = DateTime.Parse("09-11-1999"), Email = "duda@gmail.com", Instagram = "Duda_Monteiro", Telefone = "35997199625", Observacoes = "Tendinite", PersonalId = 3 });
                context.SaveChanges();

            }

            if (!context.Personais.Any())
            {
                context.Personais.AddRange(
                    new Personal { Nome = "Joaquim", Especialidade = "Funcional" },
                        new Personal { Nome = "Tiago", Especialidade = "Aerobica" },
                        new Personal { Nome = "Carlos", Especialidade = "Dança" },
                        new Personal { Nome = "Carla", Especialidade = "Crossfit" },
                        new Personal { Nome = "Fernando", Especialidade = "Meditação" });
                context.SaveChanges();
            }

            if (!context.Treinos.Any())
            {
                context.Treinos.AddRange(
                    new Treino { AlunoId = 1, PersonalId = 2, Data = new DateTime(2024, 1, 1), Hora = new DateTime(2024, 1, 1, 12, 0, 0) },
                    new Treino { AlunoId = 2, PersonalId = 4, Data = new DateTime(2024, 1, 1), Hora = new DateTime(2024, 1, 1, 12, 0, 0) },
                new Treino { AlunoId = 3, PersonalId = 1, Data = new DateTime(2024, 1, 1), Hora = new DateTime(2024, 1, 1, 12, 0, 0) });
                context.SaveChanges();
            }
            if (!context.Exercicios.Any())
            {
                context.Exercicios.AddRange(
                    new Exercicio { Nome = "elevação pélvica", Categoria = "Gluteos", Descricao = "Elevação pélvica feita na Pelvic Lift Machine" },
                    new Exercicio { Nome = "Voador", Categoria = "Bícepes", Descricao = "Exercicio feito no paarelho de voador" },
                    new Exercicio { Nome = "Burpee", Categoria = "Crossfit", Descricao = "Salto e flexão" });
                context.SaveChanges();
            }
        }
    }
}
